<nav id="sub_menu">
	<ul>
		<li><a href="/basic/center/notice.php">Notice</a></li>
		<li><a href="#">Data Download</a></li>
	</ul>
</nav>
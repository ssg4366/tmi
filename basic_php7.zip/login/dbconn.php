<?php
$mysql_hostname = 'tmi-db.c58r4f61th5t.ap-northeast-2.rds.amazonaws.com';
$mysql_username = 'tmidb';
$mysql_password = 'tmipw503';
$mysql_database = 'TMI';

$connect = mysqli_connect($mysql_hostname, $mysql_username, $mysql_password, $mysql_database);
	
mysqli_select_db($connect, $mysql_database) or die('DB connection ERROR');
?>

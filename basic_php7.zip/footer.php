	<footer>
			<hr>
			
			<div id="copy">
			Copyright 2021 kyes Inc. all rights reserved 
			contact mail : bluesky@together.co.kr Tel: +82 010-1234-1234
			</div>
			<div id="social">
				<img src="../images/facebook.gif" width="33" height="33" alt="Facebook">
				<img src="../images/twitter.gif" width="33" height="33" alt="twitter">
				
			</div>
			
		</footer>
	</div><!-- wrap -->
	</body>
</html>